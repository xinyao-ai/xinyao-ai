﻿@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0建立賽特神諭桌面捷徑.ps1"
