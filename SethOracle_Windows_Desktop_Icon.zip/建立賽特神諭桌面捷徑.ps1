﻿$ErrorActionPreference = 'Stop'
try {
  $source = Join-Path $PSScriptRoot 'SethOracle.ico'
  if (-not (Test-Path -LiteralPath $source)) { throw '找不到 SethOracle.ico，請先解壓縮整個 ZIP。' }
  $iconDir = Join-Path $env:LOCALAPPDATA 'SethOracle'
  New-Item -ItemType Directory -Path $iconDir -Force | Out-Null
  $iconPath = Join-Path $iconDir 'SethOracle.ico'
  Copy-Item -LiteralPath $source -Destination $iconPath -Force
  $candidates = @(
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe')
  )
  $browser = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
  if (-not $browser) { throw '找不到 Chrome 或 Edge，請先安裝其中一個瀏覽器。' }
  $desktop = [Environment]::GetFolderPath('Desktop')
  $linkPath = Join-Path $desktop '賽特神諭.lnk'
  $shell = New-Object -ComObject WScript.Shell
  $link = $shell.CreateShortcut($linkPath)
  $link.TargetPath = $browser
  $link.Arguments = '--app="https://xinyao-ai.github.io/xinyao-ai/?v=5037"'
  $link.WorkingDirectory = Split-Path $browser -Parent
  $link.IconLocation = $iconPath + ',0'
  $link.Description = '賽特神諭 - Windows 桌面入口'
  $link.Save()
  Write-Host '成功！已在桌面建立「賽特神諭」捷徑。' -ForegroundColor Green
  Write-Host '雙擊桌面圖示即可開啟賽特神諭。'
} catch {
  Write-Host ('建立捷徑失敗：' + $_.Exception.Message) -ForegroundColor Red
}
Read-Host '按 Enter 關閉視窗'
